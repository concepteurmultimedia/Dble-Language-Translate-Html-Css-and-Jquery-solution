	function langFrench(){
		$( "#french" ).on( "click", function() {
 			$("#language").attr("href", "./css/Fr.css");
/* 			alert("french");*/
		} );
		}
	function langEnglish() {
		$( "#english" ).on( "click", function() {
 			$("#language").attr("href", "./css/En.css"); 			
/* 			alert("english");*/
		} );
	}