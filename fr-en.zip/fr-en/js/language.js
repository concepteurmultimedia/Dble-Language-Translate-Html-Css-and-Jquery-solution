	function langFrench(){
		$( "#french" ).on( "click", function() {
 			$("#language").attr("href", "./css/Fr.css");
		} );
		}
	function langEnglish() {
		$( "#english" ).on( "click", function() {
 			$("#language").attr("href", "./css/En.css"); 			
		} );
	}